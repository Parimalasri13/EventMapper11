import React from 'react';
import './About.css';

const AboutUs = () => {
  const domains = [
    'Artificial Intelligence',
    'Machine Learning',
    'Data Science',
    'Cyber Security',
    '5G Technology',
    'IoT',
    'Edge Computing',
    'Blockchain',
    'Robotics and Automation',
    'Bioengineering',
    'Biomedical Engineering',
    'Nanotechnology',
    'Renewable Energy',
    'Data Engineering',
    'Smart Cities',
    'AR/VR',
    'Disaster Management',
    'Water Resources Management',
    'Geo-technology',
    'Academics',
    'AI Ethics',
    'Control Systems',
    'Process Intensification',
    'Personalized Medicine',
    'Bio-pharmaceutical',
    'Design and Actuation',
    'Health Management',
    'Environmental Engineering',
    'Consumption Technology'
  ];

  return (
    <div className="About_us_container">
      <header className="About_us_header">
        <h1 className="About_us_head">About Us</h1>
      </header>

      <section className="About_us_about">
        <h2 className="About_us_subhead">Welcome to EVENT MAPPERS</h2>
        <p className="About_us_content">
          Your ultimate guide to events happening across various NITs (National Institutes of Technology) and IITs (Indian Institutes of Technology) in India. We specialize in bringing you up-to-date information on a wide range of domains, allowing you to explore and participate in events that interest you the most.
        </p>
      </section>

      

      <section className="About_us_how_it_works">
        <h3 className="About_us_subhead">How It Works</h3>
        <p className="About_us_content">
          Simply click on any domain above to discover ongoing and upcoming events across different NITs and IITs.
        </p>
        <p className="About_us_content">
          Each event listing provides essential details including:
        </p>
        <ul className="About_us_content">
          <li>Event Name</li>
          <li>Date of Event</li>
          <li>Location</li>
          <li>Link to Detailed Event Information</li>
        </ul>
      </section>

      <section className="About_us_centralized_platform">
        <h3 className="About_us_subhead">Centralized Platform</h3>
        <p className="About_us_content">
          We provide a centralized platform where you can easily access detailed event descriptions directly from the respective NIT and IIT pages. This ensures you get comprehensive information about the event, its schedule, participating teams, and much more.
        </p>
      </section>

      <section className="About_us_get_involved">
        <h3 className="About_us_subhead">Get Involved</h3>
        <p className="About_us_content">
          Whether you're a student looking to participate, an enthusiast eager to explore new innovations, or simply interested in the vibrant campus cultures of NITs and IITs, EVENT MAPPER is your go-to resource. Explore, engage, and stay updated with the latest happenings across India's premier technical and cultural institutions. Join us in celebrating knowledge, creativity, and collaboration!
        </p>
      </section>

      <footer className="About_us_footer">
        <p className="About_us_content">Let's hack the future, one competition at a time. Welcome to EVENT MAPPER!</p>
      </footer>
    </div>
  );
};

export default AboutUs;
