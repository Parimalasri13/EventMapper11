// import React from 'react';
// import styled, { keyframes } from 'styled-components';

// // Define a container with a background image and gradient
// const Container = styled.div`
//   position: relative;
//   display: flex;
//   align-items: center;
//   justify-content: flex-end; /* Align content to the right */
//   height: 80vh;
//   width: 58.7vw;
//   background:
//     linear-gradient(to right, rgba(0.3, 0.5, 0.7, 0.9), transparent),
//     url('download.jpg') no-repeat;
//   background-position: right center; /* Adjust background position to right center */
//   background-size: cover; /* Ensure background image covers the container */
// `;
// const fadeIn = keyframes`
//   from {
//     opacity: 0;
//     transform: translateY(-20px); /* Optional: Initial position */
//   }
//   to {
//     opacity: 1;
//     transform: translateY(0);
//   }
// `;

// // Define keyframes for the animation
// const moveRight = keyframes`
//   from {
//     opacity: 0;
//     transform: translateX(-300px);
//   }
//   to {
//     opacity: 1;
//     transform: translateX(200);
//     left:300px:
    
//   }
// `;
// const moveRight1 = keyframes`
//   from {
//     opacity: 0;
//     transform: translateX(-300px);
//   }
//   to {
//     opacity: 1;
//     transform: translateX(200);
//     left:50px:
    
//   }
// `;

// // Define the styled component for the description
// const Description = styled.div`
//   position: absolute;
//   top: 40px;
//   left: 20px; /* Adjust left position as needed */
//   color: white;
//   text-align: center;
//   padding: 20px;
//   animation: ${moveRight} 3s forwards;
// `;
// const Description1 = styled.div`
//   position: absolute;
//   top: 200px;
//   left: 30px;

//   ul {
//     list-style-type: none; /* Remove default list styles */
//     padding: 0;
//   }

//   li {
//     padding: 10px; /* Add padding around each list item */
//     margin-bottom: 10px; /* Add margin between list items */
//     box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); /* Add shadow effect */
//     text-align: justify; /* Justify text */
//     color: white;
//     animation: ${fadeIn} .0s ease forwards; /* Apply animation to each list item */
//   }

//   h3 {
//     margin: 0; /* Remove default margin for h3 */
//   }
// `;

// // HomePage component
// const HomePage = () => {
//   return (
//     <Container>
//       <Description>
//         <h2>Don't waste your time on searching; invest it in learning.</h2>
//       </Description>
//       <Description1>
//       <ul>
//         <li><h3>Events</h3></li>
//         <li><h3>Chat With Us</h3></li>
//         <li><h3>Have Fun</h3></li>
//       </ul>
//       </Description1>
//     </Container>
//   );
// };

// export default HomePage;

import React from 'react';
import './Home.css'; // Import your CSS file for styling
import styled from 'styled-components';

// Styled-component for the image container
const ImageContainer = styled.div`
  width: 1500px;
  height: 570px;
  ${'' /* margin-left:50px; */}
  background: linear-gradient(to bottom, rgba(0, 0, 0, 0), rgba(0, 0, 0, 0.5)), 
              url('noback.png');
  background-size: cover;
  
`;



const Home = () => {
    return (
        <div className='container'>
            <ImageContainer />
            
            <div className='Description-head'>
                <h2 className='Description'>Don't waste your time on searching, invest it in learning.</h2>
                <ul className='Description2'>
                    <li>Comprehensive Event Listings at top IITs, NITs, and IIITs in one place.</li>
                    <li>Easy Access to Information by chatting with our chatbot.</li>
                    <li>See personalized recommendations based on your selected domain of interest.</li>
                </ul>
            </div>
            <div className='chat-icon'>
                <i className='fas fa-comments'></i>
               
            </div>
        </div>
    );
}

export default Home;

