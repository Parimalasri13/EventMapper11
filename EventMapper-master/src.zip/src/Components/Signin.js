import React, { useState } from 'react';
import './Signin.css';





const Signin = () => {
    const [sliderPosition, setSliderPosition] = useState(0);
const moveSlider = (position) => {
    setSliderPosition(position);
  };
  return (
    <div className="container-unique">
      <div className="slider-unique"></div>
      <div className="btn-unique">
        <button className="login-unique" onClick={() => moveSlider(0)}>Login</button>
        <button className="signup-unique" onClick={() => moveSlider(150)}>Signup</button>
      </div>
      <div className="form-section-unique">
        <div className="login-box-unique">
          <input type="email" className="email-unique ele-unique" placeholder="youremail@email.com" />
          <input type="password" className="password-unique ele-unique" placeholder="password" />
          <button className="clkbtn-unique">Login</button>
        </div>
        <div className="signup-box-unique">
          <input type="text" className="name-unique ele-unique" placeholder="Enter your name" />
          <input type="email" className="email-unique ele-unique" placeholder="youremail@email.com" />
          <input type="password" className="password-unique ele-unique" placeholder="password" />
          <input type="password" className="confirm-password-unique ele-unique" placeholder="Confirm password" />
          <button className="clkbtn-unique">Signup</button>
        </div>
      </div>
    </div>
  );
};

export default Signin;
