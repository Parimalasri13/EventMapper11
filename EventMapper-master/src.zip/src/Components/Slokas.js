// import React, { useState } from 'react';
// import './Slokas.css';

// function Slokas() {
//   const [messages, setMessages] = useState([]);
//   const [input, setInput] = useState('');

//   const handleSend = () => {
//     if (input.trim()) {
//       setMessages([...messages, { type: 'user', text: input }]);
//       setInput('');
//       // Simulate bot response
//       setTimeout(() => {
//         setMessages((prevMessages) => [
//           ...prevMessages,
//           { type: 'bot', text: 'This is a bot response to: ' + input },
//         ]);
//       }, 1000);
//     }
//   };

//   const handleInputChange = (e) => {
//     setInput(e.target.value);
//   };

//   const handleKeyPress = (e) => {
//     if (e.key === 'Enter') {
//       handleSend();
//     }
//   };

//   return (
//     <div className="chat-container">
//       <div className="chat-header">Chatbot</div>
//       <div className="chat-messages">
//         {messages.map((message, index) => (
//           <div key={index} className={`chat-message ${message.type}`}>
//             {message.text}
//           </div>
//         ))}
//       </div>
//       <div className="chat-input-container">
//         <input
//           type="text"
//           value={input}
//           onChange={handleInputChange}
//           onKeyPress={handleKeyPress}
//           placeholder="Type your question here..."
//           className="chat-input"
//         />
//         <button onClick={handleSend} className="chat-send-button">
//           Send
//         </button>
//       </div>
//     </div>
//   );
// }

// export default Slokas;


import React, { useState } from 'react';
import './Slokas.css';

function App() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');

  const handleSend = () => {
    if (input.trim()) {
      setMessages([...messages, { type: 'user', text: input }]);
      setInput('');
      // Simulate bot response
      setTimeout(() => {
        setMessages((prevMessages) => [
          ...prevMessages,
          { type: 'bot', text: 'This is a bot response to: ' + input },
        ]);
      }, 1000);
    }
  };

  const handleInputChange = (e) => {
    setInput(e.target.value);
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      handleSend();
    }
  };

  return (
    <div className="chat_bot_container">
      <div className="chat_bot_header">Chatbot</div>
      <div className="chat_bot_messages">
        {messages.map((message, index) => (
          <div key={index} className={`chat_bot_message ${message.type}`}>
            {message.text}
          </div>
        ))}
      </div>
      <div className="chat_bot_input_container">
        <input
          type="text"
          value={input}
          onChange={handleInputChange}
          onKeyPress={handleKeyPress}
          placeholder="Type your question here..."
          className="chat_bot_input"
        />
        <button onClick={handleSend} className="chat_bot_send_button">
          Send
        </button>
      </div>
    </div>
  );
}

export default App;
