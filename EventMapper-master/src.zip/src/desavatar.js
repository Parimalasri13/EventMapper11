const myths = [
{
    img :  "/Images/varaha.jpg",
    ques : "Mathya Aavataram",
    resn : "Ringing bells in temples serves to focus the mind on the divine by eliminating external distractions and to invite positive energy while dispelling negativity. It symbolizes the presence of the divine and awakens the worshipper's inner spiritual awareness."
},
{
    img :  "/Images/TempleBell.jpeg",
    ques : "Mathya Aavataram",
    resn : "Ringing bells in temples serves to focus the mind on the divine by eliminating external distractions and to invite positive energy while dispelling negativity. It symbolizes the presence of the divine and awakens the worshipper's inner spiritual awareness."
}
]
export default myths;