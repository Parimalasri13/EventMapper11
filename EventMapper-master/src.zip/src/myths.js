const myths = [
    {
        img :  "artificial intelligence.jpeg",
        ques : "Artificial Intelligence",
        link : "/ai"
    },
    {
        img :  "/machine learning.jpeg",
        ques : "Machine Learning",
        link : "/about"
    },
    {
        img :  "/data science.jpeg",
        ques : "Data Science",
        link : "/"
    },
    {
        img :  "/cybersecurity.jpeg",
        ques : "Cyber Security",
        link : "/"
    },
    {
        img :  "/5g technology.jpeg",
        ques : "5g Technology",
        link : "/"
    },
    {
        img :  "/iot.jpeg",
        ques : "IoT",
        link : "/"
    },
    {
        img :  "/edge computing.jpeg",
        ques : "Edge Computing",
        link : "/"
    },
    {
        img :  "/blockchain.jpeg",
        ques : "BlockChain",
        link : "/"
    },
    // {
    //     img :  "/robotics and automation.jpeg",
    //     ques : "Robotics and Automation",
    //     link : "/"
    // },
    {
        img :  "/bioengineering.jpeg",
        ques : "Bioengineering",
        link : "/"
    },
    // {
    //     img :  "/biomedical engineering.jpeg",
    //     ques : "Biomedical Engineering",
    //     link : "/"
    // },
    {
        img :  "/nanotechnology.jpeg",
        ques : "Nanotechnology",
        link : "/"
    },
    // {
    //     img :  "/renewable energy.jpeg",
    //     ques : "Renewable Energy",
    //     link : "/"
    //  }
    {
        img :  "/data engineering.jpeg",
        ques : "Data Engineering",
        link : "/"
    },
    {
        img :  "/ar,vr.jpeg",
        ques : "AR/VR",
        link : "/"
    },
    // {
    //     img :  "/disaster management.jpeg",
    //     ques : "Disaster Management",
    //     link : "/"
    // },
    // {
    //     img :  "/water resources management.jpeg",
    //     ques : "Water Resources Management",
    //     link : "/"
    // },
    // {
    //     img :  "/geotechnology.jpeg",
    //     ques : "Geo-Technology",
    //     link : "/"
    // }
    // {
    //     img :  "academics.jpeg",
    //     ques : "Academics",
    //     link : "/"
    // },
    // {
    //     img :  "/ai ethics.jpeg",
    //     ques : "AI Ethics",
    //     link : "/"
    // },
    // {
    //     img :  "hospital-management.jpg",
    //     ques : "Hospital Management",
    //     link : "/"
    // },
    // {
    //     img :  "smart city.jpeg",
    //     ques : "Smart City",
    //     link : "/"
    // }
    // {
    //     img :  "robotics.jpeg",
    //     ques : "Robotics",
    //     link : "/"
    // },
    // {
    //     img :  "/sustainable city.jpeg",
    //     ques : "Sustainable City",
    //     link : "/"
    // },
    // {
    //     img :  "/control systems.jpeg",
    //     ques : "Control Systems",
    //     link : "/"
    // },
    // {
    //     img :  "/process intensification.jpeg",
    //     ques : "Process Intensification",
    //     link : "/"
    // },
    // {
    //     img :  "/personalized medicine.webp",
    //     ques : "Personalized Medicine",
    //     link : "/"
    // },
    // {
    //     img :  "/bio-pharmaceutical.jpeg",
    //     ques : "Bio-Pharmaceutical",
    //     link : "/"
    // },
    // {
    //     img :  "/design and actuation.avif",
    //     ques : "Design and Actuation",
    //     link : "/"
    // },
    // {
    //     img :  "\heslth management.jpg",
    //     ques : "Health Management",
    //     link : "/"
    // },
    // {
    //     img :  "/environmental engineering.jpeg.jpg",
    //     ques : "Environmental Engineering",
    //     link : "/"
    // },
    // {
    //     img :  "/cons.jpg",
    //     ques : "Consumption Technology",
    //     link : "/"
    // },
]
export default myths;